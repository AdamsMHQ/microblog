# __init__.py
import sys
sys.path.append('/home/tarena/aid1803/microblog/')
# sys.path.append('/Users/vicshang/kepner/study/aid1803/microblog/')