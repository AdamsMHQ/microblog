# a = """<?xml version="1.0" encoding="UTF-8"?><microblog><header><interfaceVersion></interfaceVersion><transTimeSource></transTimeSource><transTimeDestination></transTimeDestination><transType>1001</transType><source></source><destination></destination></header><body><LoginReq><username>zhangsan</username><passwd>123456</passwd><mac></mac></LoginReq></body></microblog>"""


# print("%05d"%len(a)+a)

# tarena@tedu:~/aid1803/microblog/microblog/tests$ python3 a.py
# 00363<?xml version="1.0" encoding="UTF-8"?><microblog><header><interfaceVersion></interfaceVersion><transTimeSource></transTimeSource><transTimeDestination></transTimeDestination><transType>1001</transType><source></source><destination></destination></header><body><LoginReq><username>zhangsan</username><passwd>123456</passwd><mac></mac></LoginReq></body></microblog>


00363<?xml version="1.0" encoding="UTF-8"?><microblog><header><interfaceVersion></interfaceVersion><transTimeSource></transTimeSource><transTimeDestination></transTimeDestination><transType>1001</transType><source></source><destination></destination></header><body><LoginReq><username>zhangsan</username><passwd>123456</passwd><mac></mac></LoginReq></body></microblog>
00391<?xml version="1.0" encoding="utf-8"?><microblog><header><interfaceVersion>00.00.00</interfaceVersion><transTimeSource>20180526182359</transTimeSource><transTimeDestination>20180526182359</transTimeDestination><source>C</source><destination>S</destination><transtype>1001</transtype></header><body><LoginReq><username>zhangsan</username><passwd>123456</passwd></LoginReq></body></microblog>
00385<?xml version="1.0" encoding="utf-8"?><microblog><header><interfaceVersion>00.00.00</interfaceVersion><transTimeSource>20180605104654</transTimeSource><transTimeDestination>20180605104654</transTimeDestination><source>C</source><destination>S</destination><transType>1004</transType></header><body><PublishReq><userid>1</userid><msginfo>hello</msginfo></PublishReq></body></microblog>