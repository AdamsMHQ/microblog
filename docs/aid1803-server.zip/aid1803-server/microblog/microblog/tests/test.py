# test.py

import time
print ("12小时格式:" + time.strftime("%I%M%S"))
print ("今日的日期:" + time.strftime("%Y%m%d"))
