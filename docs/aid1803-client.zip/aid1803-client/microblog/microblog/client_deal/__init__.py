# __init__.py
import sys
sys.path.append('/home/tarena/aid1803/microblog/microblog/server_deal')
# sys.path.append('/Users/vicshang/kepner/study/aid1803/microblog/microblog/server_deal')


# sys.path.append('/Users/guolei/Desktop/aid1803/microblog/microblog/client_deal')
